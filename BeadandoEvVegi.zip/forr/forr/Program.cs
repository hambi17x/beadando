﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using SensorLib.Models;
using SensorLib.Network;
using SensorLib.Events;
using SensorSimulator.Data;
using SensorSimulator.Utils;

namespace SensorSimulator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Sensor Network Simulator ===");

            // Létrehozunk pár szenzort
            var nodes = new List<SensorNode>
            {
                new SensorNode("Field North"),   // Author: Fehér Zoltán
                new SensorNode("Field East"),
                new SensorNode("Pump Station"),
                new SensorNode("Reservoir"),
                new SensorNode("Bridge")
            };

            // Inicializáljuk a hálózatot (a SensorLib.dll-ben)
            var network = new SensorNetwork(nodes);

            // DB init
            var dbFile = "measurements.db";
            var db = new Database(dbFile);
            db.Initialize(); // ha nem létezik, létrehozza a táblákat

            // JSON exporter
            var exporter = new JsonExporter("measurements.json");

            // Feliratkozás az eseményre (MeasurementTaken)
            network.MeasurementTaken += (sender, ev) =>
            {
                // esemény-kezelés: kiírjuk a konzolra röviden
                Console.WriteLine($"[EVENT] {ev.Measurement}");
            };

            // Delegált: feldolgozás -> adatbázisba mentés és JSON-gyűjtés
            network.OnDataProcessed += (measurement) =>
            {
                // adatbázisba mentés
                db.InsertMeasurement(measurement);

                // JSON-be gyűjtés (memóriába; végén írjuk ki)
                exporter.Add(measurement);
            };

            // Indítjuk a szimulációt 1s mintavételi idővel
            network.Start(intervalMs: 1000);

            Console.WriteLine("Szimuláció fut. Nyomj Enter-t a leállításhoz és az eredmények kiírásához...");
            Console.ReadLine();

            // leállítjuk
            network.Stop();

            // JSON fájl írás
            exporter.Save();

            // Futtatunk LINQ lekérdezéseket az adatbázisból
            Console.WriteLine();
            Console.WriteLine("=== LINQ lekérdezések az adatbázisból ===");

            var all = db.LoadAllMeasurements(); // visszaad IEnumerable<Measurement>

            // 1) Átlaghőmérséklet szenzoronként (LINQ1)
            var avgTempPerSensor = all
                .Where(m => m.Parameter == "temperature")
                .GroupBy(m => m.SensorId)
                .Select(g => new { SensorId = g.Key, AvgTemp = g.Average(x => x.Value), Count = g.Count() })
                .ToList();

            Console.WriteLine("Átlag hőmérséklet szenzoronként:");
            foreach (var item in avgTempPerSensor)
            {
                Console.WriteLine($" Sensor {item.SensorId} : {item.AvgTemp:F2} °C ({item.Count} mérés)");
            }

            // 2) Legmagasabb páratartalom mérések (LINQ2)
            var topHumidity = all
                .Where(m => m.Parameter == "humidity")
                .OrderByDescending(m => m.Value)
                .Take(5)
                .ToList();

            Console.WriteLine("Top 5 páratartalom mérés (legnagyobbak):");
            foreach (var m in topHumidity)
                Console.WriteLine($" {m.Timestamp:O} | Sensor {m.SensorId} : {m.Value:F2}%");

            // 3) Utolsó mérések per szenzor (LINQ3)
            var lastPerSensor = all
                .GroupBy(m => m.SensorId)
                .Select(g => g.OrderByDescending(x => x.Timestamp).First())
                .ToList();

            Console.WriteLine("Utolsó mérés szenzoronként:");
            foreach (var m in lastPerSensor)
                Console.WriteLine($" Sensor {m.SensorId} | {m.Parameter} = {m.Value:F2} @ {m.Timestamp:O}");

            // Rövid statisztika
            Console.WriteLine();
            Console.WriteLine($"Összes mérés: {all.Count()}");
            Console.WriteLine($"Adatbázis fájl: {Path.GetFullPath(dbFile)}");
            Console.WriteLine($"JSON fájl: {Path.GetFullPath(exporter.FileName)}");

            Console.WriteLine("Kész. Kilépéshez nyomj Enter-t...");
            Console.ReadLine();
        }
    }
}