﻿using System;

namespace SensorLib.Models
{
    /// <summary>
    /// Egy mérési adatot reprezentál: idő, szenzor azonosító, típus és érték.
    /// </summary>
    public class Measurement
    {
        public Guid SensorId { get; set; }
        public DateTime Timestamp { get; set; }
        public string Parameter { get; set; } // e.g. "temperature", "humidity", "waterlevel"
        public double Value { get; set; }

        public Measurement() { }

        public Measurement(Guid sensorId, DateTime timestamp, string parameter, double value)
        {
            SensorId = sensorId;
            Timestamp = timestamp;
            Parameter = parameter;
            Value = value;
        }

        public override string ToString()
        {
            return $"{Timestamp:O} | Sensor {SensorId} | {Parameter} = {Value:F2}";
        }
    }
}

