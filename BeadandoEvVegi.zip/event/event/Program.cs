﻿using System;
using System.Diagnostics.Metrics;
using SensorLib.Models;

namespace SensorLib.Events
{
    /// <summary>
    /// Eseményargumentum, amikor egy mérés keletkezik.
    /// </summary>
    public class MeasurementEventArgs : EventArgs
    {
        public Measurement Measurement { get; private set; }
        public MeasurementEventArgs(Measurement m)
        {
            Measurement = m;
        }
    }
}