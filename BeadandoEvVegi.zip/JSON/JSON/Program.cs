﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.IO;
using System.Text.Json;
using SensorLib.Models;

namespace SensorSimulator.Utils
{
    /// <summary>
    /// Egyszerű JSON exportálás: memóriába gyűjt, majd fájlba ír.
    /// </summary>
    public class JsonExporter
    {
        private List<Measurement> _measurements = new();
        public string FileName { get; private set; }

        public JsonExporter(string fileName)
        {
            FileName = fileName;
        }

        public void Add(Measurement m) => _measurements.Add(m);

        public void Save()
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            var json = JsonSerializer.Serialize(_measurements, options);
            File.WriteAllText(FileName, json);
        }
    }
}