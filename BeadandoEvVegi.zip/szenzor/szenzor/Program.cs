﻿using System;

namespace SensorLib.Models
{
    /// <summary>
    /// Egy autonóm szenzor-csomópont.
    /// </summary>
    public class SensorNode
    {
        public Guid Id { get; private set; }
        public string Location { get; set; }  // rövid helymegnevezés
        public SensorNode(string location)
        {
            Id = Guid.NewGuid();
            Location = location;
        }

        public override string ToString() => $"[{Id}] ({Location})";
    }
}