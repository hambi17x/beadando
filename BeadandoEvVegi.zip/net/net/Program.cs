﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using SensorLib.Models;
using SensorLib.Events;
using SensorLib.Utils;
using System.Diagnostics.Metrics;

namespace SensorLib.Network
{
    /// <summary>
    /// A szenzorhálózat osztálya. 
    /// - Delegált használata: DataHandler delegate
    /// - Esemény: MeasurementTaken
    /// </summary>
    public class SensorNetwork
    {
        // Delegált: tetszőleges külső feldolgozót enged meghívni a mérési adatokon.
        public delegate void DataHandler(Measurement m);

        // Esemény: minden alkalommal, amikor egy új mérés jön létre.
        public event EventHandler<MeasurementEventArgs> MeasurementTaken;

        // Külső feldolgozók (delegáltként) hozzáadhatók.
        public event DataHandler OnDataProcessed;

        private List<SensorNode> _nodes = new();
        private bool _running = false;
        private CancellationTokenSource _cts;

        // konstruktor
        public SensorNetwork(IEnumerable<SensorNode> nodes)
        {
            _nodes.AddRange(nodes);
        }

        /// <summary>
        /// Indítja a szimulációt: minden csomópontnál időközönként véletlenszerű mérések jönnek létre.
        /// </summary>
        /// <param name="intervalMs">alap intervallum ms</param>
        public void Start(int intervalMs = 1000)
        {
            if (_running) return;
            _running = true;
            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            Task.Run(async () =>
            {
                var rnd = new RandomGenerator();
                while (!token.IsCancellationRequested)
                {
                    foreach (var node in _nodes)
                    {
                        // generálunk néhány paramétert
                        var timestamp = DateTime.UtcNow;

                        var temp = rnd.NextDouble(5.0, 35.0); // °C
                        var hum = rnd.NextDouble(20.0, 90.0); // %
                        var water = rnd.NextDouble(0.0, 5.0); // m (vízszint)

                        var measurements = new List<Measurement>
                        {
                            new Measurement(node.Id, timestamp, "temperature", temp),
                            new Measurement(node.Id, timestamp, "humidity", hum),
                            new Measurement(node.Id, timestamp, "waterlevel", water)
                        };

                        foreach (var m in measurements)
                        {
                            // Esemény kibocsátása
                            MeasurementTaken?.Invoke(this, new MeasurementEventArgs(m));
                            // Delegált meghívása (ha van)
                            OnDataProcessed?.Invoke(m);
                        }
                    }

                    // várakozunk az intervallumig
                    await Task.Delay(intervalMs, token).ContinueWith(t => { });
                }
            }, token);
        }

        /// <summary>
        /// Leállítja a szimulációt.
        /// </summary>
        public void Stop()
        {
            if (!_running) return;
            _cts.Cancel();
            _running = false;
        }

        public IEnumerable<SensorNode> Nodes => _nodes.AsReadOnly();
    }
}