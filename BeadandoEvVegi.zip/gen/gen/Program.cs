﻿using System;

namespace SensorLib.Utils
{
    /// <summary>
    /// Egyszerű véletlenszám-generátor segédosztály,
    /// hogy könnyebb legyen tesztelni (várható hogy bővíthető).
    /// </summary>
    public class RandomGenerator
    {
        private Random _rnd;
        public RandomGenerator() => _rnd = new Random();

        // double intervallum
        public double NextDouble(double min, double max)
        {
            return min + _rnd.NextDouble() * (max - min);
        }

        // int intervallum
        public int NextInt(int min, int max)
        {
            return _rnd.Next(min, max + 1);
        }
    }
}