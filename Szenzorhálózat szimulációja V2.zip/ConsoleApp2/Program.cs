﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using LiteDB;
using Newtonsoft.Json;
using SensorLib;

namespace SensorApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Lista, amiben tároljuk az összes mérést
            List<Meres> gyujtottAdatok = new List<Meres>();

            /* Szenzorok létrehozása
               Példányosítunk két szenzort a saját osztályunkból
            */
            Szenzor hoSzenzor = new Szenzor("Szenzor", "Hőmérséklet");
            Szenzor paraSzenzor = new Szenzor("Szenzor", "Páratartalom");

            /* Feliratkozás az eseményre
               Itt megmondjuk, mi történjen, ha a hőmérő mér egyet.
            */
            hoSzenzor.MeresTortent += (kuldo, m) =>
            {
                Console.WriteLine("Mérés érkezett: " + m.ToString() + " C");
                gyujtottAdatok.Add(m);  // Hozzáadjuk a listához
                MentesLiteDB(m);        // Elmentjük adatbázisba is
            };

            // Ugyanezt megtesszük a páraszenzorral is
            paraSzenzor.MeresTortent += (kuldo, m) =>
            {
                Console.WriteLine("Mérés érkezett: " + m.ToString() + " %");
                gyujtottAdatok.Add(m);
                MentesLiteDB(m);
            };


            // Ciklusban történik szenzorok mérése
            for (int i = 0; i < 5; i++)
            {
                hoSzenzor.MeresSzimulalas();    // Ez hívja meg a háttérben az eseményt
                paraSzenzor.MeresSzimulalas();
            }

            // Mentés Json fájlba
            string jsonSzoveg = JsonConvert.SerializeObject(gyujtottAdatok, Formatting.Indented);

            // Kiírjuk a szöveget egy fájlba
            StreamWriter iro = new StreamWriter("meresek.json", false, Encoding.UTF8);
            iro.Write(jsonSzoveg);
            iro.Close();
            Console.WriteLine("JSON fájl mentve.");


            // Statisztikák (LINQ)
            Console.WriteLine("\nStatisztikák (LINQ):");

            // Kiválogatjuk csak a hőmérséklet adatokat
            var homersekletek = from x in gyujtottAdatok
                                where x.Tipus == "Hőmérséklet"
                                select x;

            // Átlag számítása
            double osszeg = 0;
            int darab = 0;
            foreach (var tetel in homersekletek)
            {
                osszeg = osszeg + tetel.Ertek;
                darab++;
            }

            if (darab > 0)
            {
                Console.WriteLine("Átlag hőmérséklet: " + (osszeg / darab));
            }

            // Érték szerint növekvő sorrendbe állítjuk az összes adatot
            var rendezettAdatok = from x in gyujtottAdatok
                                  orderby x.Ertek ascending
                                  select x;

            Console.WriteLine("Adatok érték szerint rendezve:");
            foreach (var tetel in rendezettAdatok)
            {
                Console.WriteLine(tetel.ToString());
            }

            Console.ReadKey();
        }

        // Az adatbázisba mentése
        private static void MentesLiteDB(Meres m)
        {
            using (var db = new LiteDatabase("SzenzorAdatok.db"))
            {
                // Lekérjük a 'meresek' nevű táblát (kollekciót)
                var tabla = db.GetCollection<Meres>("meresek");
                tabla.Insert(m);
            }
        }
    }
}