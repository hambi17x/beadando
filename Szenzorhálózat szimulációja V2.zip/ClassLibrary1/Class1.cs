﻿using System;

namespace SensorLib
{
    public class SzenzorAdat
    {
        private string leiras;
        public SzenzorAdat(string leiras)
        {
            this.leiras = leiras;
        }
    }

    // Ez az osztály reprezentál egyetlen mérési eredményt, csak adatokat tárol
    public class Meres
    {
        public int Id { get; set; }             // Egyedi azonosító (adatbázishoz)
        public string SzenzorNev { get; set; }  // Melyik eszköz mérte
        public string Tipus { get; set; }       // Pl. "Hőmérséklet" vagy "Páratartalom"
        public double Ertek { get; set; }       // A mért számérték
        public DateTime Ido { get; set; }       // Mikor történt a mérés

        // Felülírjuk a ToString()-et, hogy szöveget írjon ki
        public override string ToString()
        {
            string datumSzoveg = Ido.ToString("yyyy.MM.dd. HH:mm:ss");
            return datumSzoveg + " " + SzenzorNev + " (" + Tipus + "): " + Ertek;
        }
    }

    /* Meghatározza, hogy milyen paramétereket kap az, aki feliratkozik az eseményre.
       kuldo: aki küldte, m: maga a mérés.
    */
    public delegate void MeresKezelo(object kuldo, Meres m);

    // Ez az osztály szimulál egy szenzort.
    public class Szenzor
    {
        public string Nev { get; set; }
        public string MeresTipusa { get; set; }

        // ESEMÉNY (Event): Erre tud majd a főprogram feliratkozni (+ jelel), ha megtörténik a mérés

        public event MeresKezelo MeresTortent;

        private Random rnd = new Random();

        // Konstruktor: beállítja a szenzor nevét és típusát
        public Szenzor(string nev, string tipus)
        {
            Nev = nev;
            MeresTipusa = tipus;
        }

        // Ez a metódus "játssza el", hogy a szenzor mért valamit.
        public void MeresSzimulalas()
        {
            double ertek = 0;

            // Attól függően, mi a típusa, más tartományban generálunk számot
            if (MeresTipusa == "Hőmérséklet")
                ertek = rnd.Next(20, 35); 
            else
                ertek = rnd.Next(40, 80); 

            // Létrehozzuk a mérés objektumot az adatokkal
            Meres ujMeres = new Meres();
            ujMeres.SzenzorNev = Nev;
            ujMeres.Tipus = MeresTipusa;
            ujMeres.Ertek = ertek;
            ujMeres.Ido = DateTime.Now;

            // Ha van feliratkozó (nem null), akkor értesítjük őket
            if (MeresTortent != null)
            {
                MeresTortent(this, ujMeres);
            }
        }
    }
}